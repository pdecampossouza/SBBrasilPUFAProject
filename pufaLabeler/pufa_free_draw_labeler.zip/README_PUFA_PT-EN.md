# PUFA Free-Draw Labeler — Setup & Instructions (PT / EN)

## 🇧🇷 Instruções em Português

### 🧩 Pré-requisitos
- Python 3.10 ou 3.11 instalado.
- Descompacte este arquivo ZIP em uma pasta simples (ex.: `C:\PUFA` ou `~/PUFA`).

### 🖥️ Configuração do ambiente
Abra o terminal nesta pasta e execute:

```bash
python -m venv .venv
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
# macOS/Linux
source .venv/bin/activate

pip install --upgrade pip
pip install "streamlit==1.40.0" numpy pandas pillow opencv-python streamlit-drawable-canvas
```

### ▶️ Execução
Rode o aplicativo:
```bash
python -m streamlit run pufa_free_draw_labeler.py
```
O navegador abrirá automaticamente (ou acesse http://localhost:8501).

### 🦷 Fluxo de anotação
1. Preencha **Your name / ID** com seu nome ou código.
2. Selecione uma imagem (use **Prev/Next**).
3. Desenhe um retângulo sobre o dente de interesse.
4. Escolha a **PUFA label** e clique **Add annotation**.
5. Repita para todos os dentes da imagem.
6. Ao terminar, clique **Export crops & update manifest**.

### 💾 Envio dos resultados
Envie de volta:
- `annotations/tooth_labels_free_draw.json`
- `metadata/manifest_teeth.csv`
- (opcional) `images_by_tooth/PUFA/` com os recortes.

### ⚙️ Estrutura esperada
```
PUFA/
├─ pufa_free_draw_labeler.py
├─ Pranchetas fotografias - PUFA - treinamento/
├─ annotations/
│   └─ tooth_labels_free_draw.json
├─ images_by_tooth/
│   └─ PUFA/
└─ metadata/
    └─ manifest_teeth.csv
```

---

## 🇬🇧 Instructions in English

### 🧩 Requirements
- Python 3.10 or 3.11 installed.
- Unzip this file into a simple path (e.g., `C:\PUFA` or `~/PUFA`).

### 🖥️ Environment setup
Open a terminal in that folder and run:

```bash
python -m venv .venv
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
# macOS/Linux
source .venv/bin/activate

pip install --upgrade pip
pip install "streamlit==1.40.0" numpy pandas pillow opencv-python streamlit-drawable-canvas
```

### ▶️ Run
```bash
python -m streamlit run pufa_free_draw_labeler.py
```
Your browser will open (or go to http://localhost:8501).

### 🦷 Labeling workflow
1. Fill **Your name / ID** (your name or code).
2. Select an image (use **Prev/Next**).
3. Draw a rectangle around the target tooth.
4. Choose the **PUFA label** and click **Add annotation**.
5. Repeat for all relevant teeth.
6. Click **Export crops & update manifest** when finished.

### 💾 What to send back
- `annotations/tooth_labels_free_draw.json`
- `metadata/manifest_teeth.csv`
- (optional) `images_by_tooth/PUFA/` with crops.

### ⚙️ Folder layout
```
PUFA/
├─ pufa_free_draw_labeler.py
├─ Pranchetas fotografias - PUFA - treinamento/
├─ annotations/
│   └─ tooth_labels_free_draw.json
├─ images_by_tooth/
│   └─ PUFA/
└─ metadata/
    └─ manifest_teeth.csv
```
